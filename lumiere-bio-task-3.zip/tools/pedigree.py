#!/usr/bin/env python3
"""Four generation pedigree for an autosomal recessive condition, with two consanguineous
marriages, drawn to standard conventions, plus an exact solver for the carrier risk question.

Run:  python3 pedigree.py          writes fig.svg, fig.html, truth.json and prints the answer
"""
import os, json, itertools
from fractions import Fraction as F

# ---------------------------------------------------------------- the family
# key: (generation, x position in units, sex, affected, parents or None)
# Outsiders are people with parents None who are not the two founders.
U = 125                     # pixels per x unit
ROW = {1: 230, 2: 600, 3: 970, 4: 1340}
W, H = 3200, 1560

P = {}
def add(k, g, x, sex, aff=False, par=None): P[k] = dict(g=g, x=x, sex=sex, aff=aff, par=par)

add("I1", 1, 10.5, "M"); add("I2", 1, 12.5, "F")
# generation II: four children of I1 x I2 and their spouses
add("Ap", 2, 1.5, "M");  add("A", 2, 3.0, "F", True, ("I1", "I2"))
add("B", 2, 6.0, "M", False, ("I1", "I2")); add("Bp", 2, 7.5, "F")
add("Cp", 2, 13.5, "M"); add("C", 2, 15.0, "F", False, ("I1", "I2"))
add("D", 2, 18.5, "M", False, ("I1", "I2")); add("Dp", 2, 20.0, "F")
# generation III
add("a2", 3, 1.0, "M", False, ("Ap", "A"))
add("b1p", 3, 2.5, "F")
add("b1", 3, 4.0, "M", False, ("B", "Bp"))
add("b2", 3, 5.5, "F", False, ("B", "Bp"))
add("b2p", 3, 7.0, "M")
add("b3", 3, 8.5, "M", False, ("B", "Bp"))
add("c1", 3, 10.0, "F", False, ("Cp", "C"))
add("c2", 3, 11.5, "M", False, ("Cp", "C"))
add("a1", 3, 13.0, "F", False, ("Ap", "A"))
add("c3", 3, 14.5, "F", False, ("Cp", "C"))
add("c4", 3, 16.0, "M", False, ("Cp", "C"))
add("d1", 3, 18.0, "F", False, ("D", "Dp"))
add("d2", 3, 19.5, "M", False, ("D", "Dp"))
# generation IV
add("e1", 4, 2.5, "F", False, ("b1", "b1p"))
add("e2", 4, 4.0, "M", False, ("b1", "b1p"))
add("f1", 4, 6.25, "M", False, ("b2", "b2p"))
add("k1", 4, 9.25, "F", False, ("b3", "c1"))
add("g1", 4, 11.0, "M", True, ("c2", "a1"))
add("g2", 4, 12.5, "M", False, ("c2", "a1"))
add("g3", 4, 14.0, "F", False, ("c2", "a1"))
add("m1", 4, 17.25, "F", False, ("a2", "d1"))
add("m2", 4, 18.75, "M", False, ("a2", "d1"))

# marriages: (left partner, right partner, consanguineous, route)
# route None: straight line between adjacent partners
# route y_offset: double line dropped below the row, run across, and raised to the partner
MARRIAGES = [
    ("I1", "I2", False, None), ("Ap", "A", False, None), ("B", "Bp", False, None),
    ("Cp", "C", False, None), ("D", "Dp", False, None),
    ("b1p", "b1", False, None), ("b2", "b2p", False, None),
    ("b3", "c1", True, None), ("c2", "a1", True, None),
    ("a2", "d1", True, 0.30),
]
# sibship line height below the parents' row, as a fraction of the row gap, per couple
SIB_OFF = {("I1", "I2"): 0.45, ("Ap", "A"): 0.30, ("B", "Bp"): 0.52, ("Cp", "C"): 0.52,
           ("D", "Dp"): 0.52, ("b1", "b1p"): 0.45, ("b2", "b2p"): 0.45, ("b3", "c1"): 0.45,
           ("c2", "a1"): 0.45, ("a2", "d1"): 0.45}

# ---------------------------------------------------------------- numbering
ROMAN = {1: "I", 2: "II", 3: "III", 4: "IV"}
label = {}
for g in ROM if (ROM := None) else ROMAN:
    row = sorted((v["x"], k) for k, v in P.items() if v["g"] == g)
    for i, (_, k) in enumerate(row, 1):
        label[k] = f"{ROMAN[g]}-{i}"

# ---------------------------------------------------------------- exact solver
# Genotypes 0 = DD, 1 = Dd, 2 = dd.  Founders I1, I2 are unaffected; outsiders are DD.
FOUNDERS = {"I1", "I2"}
outsiders = {k for k, v in P.items() if v["par"] is None and k not in FOUNDERS}
in_family = [k for k, v in P.items() if v["par"] is not None]
children_of = {}
for k, v in P.items():
    if v["par"]: children_of.setdefault(tuple(v["par"]), []).append(k)

def transmit(ga, gb):
    """distribution of child genotype given parent genotypes"""
    pa = {0: (F(1), F(0)), 1: (F(1, 2), F(1, 2)), 2: (F(0), F(1))}  # P(D), P(d)
    out = {0: F(0), 1: F(0), 2: F(0)}
    for i, pi in enumerate(pa[ga]):
        for j, pj in enumerate(pa[gb]):
            out[i + j] += pi * pj
    return out

# individuals whose genotype must be enumerated: in-family people who have children
parents_set = {p for cpl in children_of for p in cpl}
enum = [k for k in in_family if k in parents_set]
leaves = [k for k in in_family if k not in parents_set]
print("enumerated:", enum)
print("leaf children:", leaves)

def pheno_ok(k, geno):
    return (geno == 2) == P[k]["aff"]

TARGETS = ("k1", "g2")   # the couple whose child is asked about
total = F(0); acc = F(0); carrier = {t: F(0) for t in TARGETS}
G = {"I1": 1, "I2": 1}
for o in outsiders: G[o] = 0
# founders could in principle be DD or Dd; an affected child forces Dd for both, so fixing
# them to Dd loses nothing. We also run the DD/Dd variants below as a check.
def run(founder_g):
    tot = F(0); joint = F(0); car = {t: F(0) for t in TARGETS}
    G["I1"], G["I2"] = founder_g
    for combo in itertools.product((0, 1, 2), repeat=len(enum)):
        w = F(1)
        for k, gk in zip(enum, combo):
            G[k] = gk
        ok = True
        for k, gk in zip(enum, combo):
            if not pheno_ok(k, gk): ok = False; break
            pa, pb = P[k]["par"]
            w *= transmit(G[pa], G[pb])[gk]
            if w == 0: ok = False; break
        if not ok: continue
        # leaf children: multiply by P(phenotype | parents); keep carrier prob for targets
        tcar = {}
        for k in leaves:
            pa, pb = P[k]["par"]
            d = transmit(G[pa], G[pb])
            if P[k]["aff"]:
                w *= d[2]
            else:
                w *= (d[0] + d[1])
                if k in TARGETS:
                    tcar[k] = d[1] / (d[0] + d[1]) if (d[0] + d[1]) else F(0)
            if w == 0: break
        if w == 0: continue
        tot += w
        for t in TARGETS: car[t] += w * tcar.get(t, F(0))
        joint += w * tcar.get(TARGETS[0], F(0)) * tcar.get(TARGETS[1], F(0))
    return tot, car, joint

tot, car, joint = run((1, 1))
pk1 = car["k1"] / tot; pg2 = car["g2"] / tot; pjoint = joint / tot
risk = pjoint / 4
print(f"P({label['k1']} carrier) = {pk1} = {float(pk1):.6f}")
print(f"P({label['g2']} carrier) = {pg2} = {float(pg2):.6f}")
print(f"P(both carriers)        = {pjoint}  (product of marginals {pk1*pg2})")
print(f"risk to a child          = {risk} = {float(risk):.6f}")
# check that founder prior does not matter
for fg in ((0, 1), (1, 0), (0, 0)):
    t2, c2_, j2 = run(fg)
    print("  founders", fg, "total weight", t2, "(should be 0: an affected child needs both Dd)")

truth = dict(label=label, k1=str(pk1), g2=str(pg2), joint=str(pjoint), risk=str(risk),
             risk_float=float(risk))

# ---------------------------------------------------------------- drawing
S = 34          # half size of a symbol
FONT = "Liberation Sans, Arial, Helvetica, sans-serif"
out = []
def w_(s): out.append(s)
def X(x): return 150 + x * U
def Y(g): return ROW[g]
def line(x1, y1, x2, y2, sw=4, c="#111"):
    w_(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{c}" stroke-width="{sw}" stroke-linecap="square"/>')
def dline(pts, gap=9):
    """double line along a polyline, for consanguinity"""
    for off in (-gap / 2, gap / 2):
        d = " ".join(f"{x:.1f},{y + off:.1f}" if i % 2 == 0 or True else "" for i, (x, y) in enumerate(pts))
        w_(f'<polyline points="{d}" fill="none" stroke="#111" stroke-width="4"/>')

w_(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">')
w_(f'<rect width="{W}" height="{H}" fill="#ffffff"/>')
# generation labels
for g in ROMAN:
    w_(f'<text x="60" y="{Y(g)}" font-family="{FONT}" font-size="48" font-weight="bold" dominant-baseline="middle" fill="#111">{ROMAN[g]}</text>')

# marriage lines
for a, b, cons, route in MARRIAGES:
    xa, xb = X(P[a]["x"]), X(P[b]["x"]); y = Y(P[a]["g"])
    if route is None:
        if cons:
            line(xa + S, y - 5, xb - S, y - 5); line(xa + S, y + 5, xb - S, y + 5)
        else:
            line(xa + S, y, xb - S, y)
    else:
        yr = y + route * (ROW[2] - ROW[1])
        for off in (-5, 5):
            # down from a, across, up to b: draw as three segments offset for a double line
            line(xa + off, y + S, xa + off, yr + off * 0 + (0), 4)
        line(xa - 5, yr - 5, xb - 5, yr - 5, 4); line(xa + 5, yr + 5, xb + 5, yr + 5, 4)
        line(xa - 5, y + S, xa - 5, yr - 5, 4); line(xa + 5, y + S, xa + 5, yr + 5, 4)
        line(xb - 5, y + S, xb - 5, yr - 5, 4); line(xb + 5, y + S, xb + 5, yr + 5, 4)

# sibship lines and drops
for cpl, kids in children_of.items():
    a, b = cpl
    g = P[a]["g"]; y = Y(g)
    route = next((r for (p, q, c, r) in MARRIAGES if {p, q} == {a, b}), None)
    xm = (X(P[a]["x"]) + X(P[b]["x"])) / 2
    ytop = y
    if route is not None:
        ytop = y + route * (ROW[2] - ROW[1]) + 5
        xm = X(P["d1"]["x"])      # drop from the routed line under the in-row partner
    ys = y + SIB_OFF[cpl] * (ROW[g + 1] - ROW[g])
    xs = [X(P[k]["x"]) for k in kids]
    line(xm, ytop, xm, ys)                       # drop from marriage to sibship line
    if len(kids) > 1:
        line(min(xs + [xm]), ys, max(xs + [xm]), ys)
    for k in kids:
        line(X(P[k]["x"]), ys, X(P[k]["x"]), Y(g + 1) - S)

ROUTED = {a for a, b, c, r in MARRIAGES if r is not None} | {b for a, b, c, r in MARRIAGES if r is not None}
# symbols and labels
for k, v in P.items():
    x, y = X(v["x"]), Y(v["g"])
    fill = "#111" if v["aff"] else "#fff"
    if v["sex"] == "M":
        w_(f'<rect x="{x - S}" y="{y - S}" width="{2 * S}" height="{2 * S}" fill="{fill}" stroke="#111" stroke-width="4"/>')
    else:
        w_(f'<circle cx="{x}" cy="{y}" r="{S}" fill="{fill}" stroke="#111" stroke-width="4"/>')
    ly_ = y - S - 34 if k in ROUTED else y + S + 40
    w_(f'<text x="{x}" y="{ly_}" font-family="{FONT}" font-size="30" text-anchor="middle" dominant-baseline="middle" fill="#111">{label[k]}</text>')

# legend, bottom left
lx, ly = 150, H - 90
w_(f'<rect x="{lx}" y="{ly - 20}" width="40" height="40" fill="#fff" stroke="#111" stroke-width="3"/>')
w_(f'<text x="{lx + 60}" y="{ly}" font-family="{FONT}" font-size="30" dominant-baseline="middle">male</text>')
w_(f'<circle cx="{lx + 200}" cy="{ly}" r="20" fill="#fff" stroke="#111" stroke-width="3"/>')
w_(f'<text x="{lx + 240}" y="{ly}" font-family="{FONT}" font-size="30" dominant-baseline="middle">female</text>')
w_(f'<rect x="{lx + 400}" y="{ly - 20}" width="40" height="40" fill="#111" stroke="#111" stroke-width="3"/>')
w_(f'<text x="{lx + 460}" y="{ly}" font-family="{FONT}" font-size="30" dominant-baseline="middle">affected</text>')
w_(f'<line x1="{lx + 640}" y1="{ly - 5}" x2="{lx + 720}" y2="{ly - 5}" stroke="#111" stroke-width="4"/>')
w_(f'<line x1="{lx + 640}" y1="{ly + 5}" x2="{lx + 720}" y2="{ly + 5}" stroke="#111" stroke-width="4"/>')
w_(f'<text x="{lx + 740}" y="{ly}" font-family="{FONT}" font-size="30" dominant-baseline="middle">consanguineous marriage</text>')
w_('</svg>')

here = os.path.dirname(os.path.abspath(__file__))
svg = "\n".join(out)
open(os.path.join(here, "fig.svg"), "w").write(svg)
open(os.path.join(here, "fig.html"), "w").write('<html><head><meta charset="utf-8"></head><body style="margin:0;background:#fff">' + svg + '</body></html>')
json.dump(truth, open(os.path.join(here, "truth.json"), "w"), indent=1)
print("labels:", {k: label[k] for k in ("A", "B", "C", "D", "b3", "c1", "c2", "a1", "a2", "d1", "k1", "g1", "g2", "g3")})
print("written")
