# Biology task 3, attempt 1: carrier risk in a four generation pedigree

Status: NOT YET RUN.

How to run it. Fill the form from the table, upload image.png, paste prompt.md word for word.
Tick boxes 1, 3 and 4 and leave box 2 for Miroslav. Wait for both model blocks and save them as
feedback/001.md with the expected answer, the verdict, the checker findings and both blocks in
full with their reasoning. Both blocks have to be wrong, so if either one lands within 2 percent
of 0.0580, which is the window 0.0568 to 0.0592, the run is over and nothing gets submitted.

| Field | Value |
|---|---|
| Subdomain | Genetics |
| Where did the image(s) come from | Original - internal lab image |
| Source URL or DOI | N/A |
| License | Original - internal lab image |
| Reference material | N/A |
| Publication venue | N/A |
| Image | image.png, 3200 x 1560, four generations, 32 people |

---

## Step 4. Prompt

In prompt.md. Paste that file and nothing else.

---

## Step 6. GTFA

0.0580

The exact value is $4/69 = 0.0579710$.

---

## Checkboxes

| Statement | Answer |
|---|---|
| I've double checked my spelling and grammar. | True |
| My prompt is not duplicative, plagiarized, or LLM-generated. | Box 2 is Miroslav's, leave it |
| My prompt is self-contained and fully solvable without external resources. | True |
| The prompt can only be solved with the information in the image. | True |

NON_FOUNDATIONAL_REFERENCE fires on every image task, record it and carry on. This prompt names
the inheritance model but leaves the whole inference unstated, which is what the Biology checker
asked for after it raised DOMAIN_KNOWLEDGE_FLOOR on task 2.

---

## Ground truth

The answer is the product of three numbers, and each one needs a different piece of the pedigree.

Step 1. II-2 is affected and she is a daughter of I-1 and I-2, who are both unaffected, so both
founders are carriers.

Step 2. IV-5 is affected, so both of his parents carry the allele. III-9 is a daughter of the
affected II-2, so she is a carrier whatever else is true. III-8 is the one that matters. He is a
son of II-5 and II-6, II-5 married in and carries two normal copies, so the allele III-8 passed
to IV-5 came from II-6. **II-6 is an obligate carrier.** This is the step the whole task turns
on, and it is two generations away from the couple being asked about.

Step 3. III-7 is another child of II-5 and II-6. With II-6 an obligate carrier and II-5 clear,
III-7 is a carrier with probability $1/2$.

Step 4. II-3 is an unaffected child of two carriers, so he is a carrier with probability $2/3$,
and III-6 is his child by II-4 who married in, so III-6 is a carrier with probability $1/3$.

Step 5. IV-4 is the only child of III-6 and III-7 and she is unaffected, so the pair of
them has to be reweighted on that fact.

| III-6 | III-7 | prior | P(one unaffected child) | weight | P(IV-4 carrier) |
|---|---|---|---|---|---|
| Dd | Dd | 1/6 | 3/4 | 1/8 | 2/3 |
| Dd | DD | 1/6 | 1 | 1/6 | 1/2 |
| DD | Dd | 1/3 | 1 | 1/3 | 1/2 |
| DD | DD | 1/3 | 1 | 1/3 | 0 |

Total weight $23/24$, carrier weight $1/3$, so P(IV-4 carrier) $= 8/23 = 0.347826$.

Step 6. IV-6 is an unaffected child of III-8 and III-9, both obligate carriers, so he is a
carrier with probability $2/3$.

Step 7. The two branches are independent once the founders are fixed as carriers, so

$$P = \frac{8}{23} \times \frac{2}{3} \times \frac{1}{4} = \frac{4}{69} = 0.0579710$$

which is $0.0580$ to three significant figures.

Checked twice by different routes. tools/pedigree.py enumerates the genotype of every person who
has children and sums over the rest exactly in fractions, and it returns $4/69$. The closed form
above was worked by hand and agrees. The script also confirms that no founder assignment other
than carrier by carrier has any weight.

## Where the levers are

The lever here is topology, not reading. The CS record is clear that packed gridlines are spent,
against the form models and against the Pass@2 reviewer, while the one design that survived was
a 20 node graph whose arrows both models misread. A pedigree is the same kind of object. Nothing
in this image needs measuring, and everything needs tracing.

1. The obligate carrier at II-6 is reached backwards, from an affected great grandchild in a
   different branch of the family. A solver who treats III-7 like III-6 and gives both $1/3$
   gets $0.0476$, which is $18$ percent low. This is the main trap.
2. IV-4 is an only child, so the reweighting in step 5 is easy to skip. Skipping it gives
   exactly $1/3$ and an answer of $0.0556$, which is $4.2$ percent low. The sibship was built
   with one child on purpose: with two children the skip lands $1.1$ percent out and inside the
   tolerance band, which would make the task invalid.
3. III-1 and III-12 are married to each other across the whole width of the chart, on a double
   line that runs under the whole of generation III. They are first cousins and their children
   IV-8 and IV-9 are a decoy. That marriage carries no information about the answer, and the
   same is true of the line between III-6 and III-7. A solver has to work that out rather than
   assume it.
4. Thirty two people, three consanguineous marriages and two affected individuals in different
   branches. The affected II-2 and the affected IV-5 have to be used for different purposes,
   one to fix the founders and one to reach back to II-6.

## Wrong answers and where they land

| slip | answer | off by |
|---|---|---|
| treats III-7 as $1/3$ like III-6, misses the obligate carrier at II-6 | 0.0476 | -17.9 percent |
| misses II-6 and skips the reweighting on IV-4 | 0.0463 | -20.1 percent |
| takes IV-6 as $1/2$ rather than $2/3$ | 0.0435 | -25.0 percent |
| skips the reweighting on IV-4 only | 0.0556 | -4.2 percent |
| forgets the final $1/4$ and reports the chance both are carriers | 0.232 | |
| answers the chance the child is a carrier rather than affected | 0.116 | |

Nothing plausible lands inside the $2$ percent band. The closest is $4.2$ percent.
