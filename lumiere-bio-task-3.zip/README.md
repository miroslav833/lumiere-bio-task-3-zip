# lumiere-bio-task-3

One Lumiere task in the Biology domain, subdomain Genetics. The image is a self authored four
generation pedigree of 32 people with three consanguineous marriages and two affected
individuals in different branches. The question asks for the chance that a child of IV-4 and
IV-6 is affected. The answer is 0.0580, exactly 4/69.

| File | What it holds |
|---|---|
| prompt.md | the prompt, the only text anybody pastes into the form |
| task.md | the form fields, the worked ground truth, the levers, the wrong answers |
| image.png | the pedigree, 3200 x 1560 |
| tools/pedigree.py | draws the pedigree and solves it exactly in fractions |
| feedback/ | one file per run, written after the models answer |

The lever is topology rather than reading. Nothing in the image needs measuring. The earlier
biology designs were both solved on the first block because they rested on reading values off
axes, which the current model does well.
