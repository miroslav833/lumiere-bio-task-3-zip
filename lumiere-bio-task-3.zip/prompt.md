Image 1 shows a four generation pedigree of one family. Filled symbols are people affected by a single gene disorder, squares are male and circles are female, and a double line between two partners marks a marriage between relatives. Each person carries a generation number and a position number under or over the symbol.

The disorder is autosomal recessive and fully penetrant, so every person with two copies of the disease allele is affected and no one else is. There is no new mutation anywhere in the family. Everybody who marries into the family from outside carries two normal copies.

IV-4 and IV-6 plan a child together. Find the probability that this child is affected.

There are some things which stay fixed. Use every phenotype drawn in Image 1 as evidence, including the people who are not affected. Each child of a given couple inherits one allele from each parent on its own, and the sexes of the children do not matter here. Treat the pedigree as the whole of the family.

Report your final answer as a 3 significant figure number without units. Any intermediate calculations should be carried out to 6 significant figures.
